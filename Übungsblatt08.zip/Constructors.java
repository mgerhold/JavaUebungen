class Constructors {

    private String s;
    private int i;
    private double d;    

    public Constructors(String s, int i, double d) {
        // hier Code einfügen
    }

    public Constructors(String s, int i) {
        // hier Code einfügen
    }

    public Constructors(String s) {
        // hier Code einfügen
    }

    public void setS(String s) {
        // Es sind nur Strings mit einer Länge von 5 Zeichen erlaubt!
        // Alle anderen Strings dürfen nicht übernommen werden! Es muss jedoch
        // sichergestellt werden, dass immer ein gültiger (ggf. leerer)
        // String vorhanden ist.
        
        // hier Code einfügen
    }

    public String getS() {
        return s;
    }

    private static void test(Constructors testSubject, int expectedLength) {
        if (testSubject.getS() == null) {
            System.out.println("Fehler! Der String sollte nicht null sein!");
            return;
        }
        int length = testSubject.getS().length();
        if (length != expectedLength) {
            System.out.println("Fehler! Der String hat eine Laenge von " + length + " (" + expectedLength + "erwartet)");
            return;
        }
        System.out.println("Test bestanden!");
    }

    public static void main(String[] args) {
        Constructors a = new Constructors("Hallo", 42, 1.23);
        test(a, 5);
        a = new Constructors("Test", 10);
        test(a, 0);
        a = new Constructors(null, 1, 4.32);
        test(a, 0);
        a = new Constructors(null);
        test(a, 0);
        a.setS("Hallo");
        test(a, 5);
        a.setS(null);
        test(a, 5);
    }

}